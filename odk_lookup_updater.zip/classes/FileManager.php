<?php
/**
 * Created by PhpStorm.
 * User: BlessK
 * Date: 1/21/2018
 * Time: 12:14 AM
 */
class FileManager
{
    private $root_folder;
    function __construct($root_folder)
    {
        $this->root_folder=$root_folder;
    }
    public function getMediaFile($folder_name)
    {
        $filelist = glob($folder_name."/*.csv");
        return $filelist;
    }

    /**
     * @return mixed
     */
    public function getRootFolder()
    {
        return $this->root_folder;
    }

    /**
     * @param mixed $root_folder
     */
    public function getMediaFolder($name_pattern)
    {
        //$filelist = glob("te*");
        $folderlist = glob($this->root_folder."/*$name_pattern", GLOB_ONLYDIR);
        return $folderlist;
    }
}