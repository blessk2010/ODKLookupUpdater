<?php
	header("Location:./not-found");
?>