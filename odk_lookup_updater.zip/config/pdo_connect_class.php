<?php
class DatabaseConnection
{
    // Make the connection:

    private static $db_conn = NULL;

    private function _construct()
    {
    }
    public static function showErrorMessage($message)
    {
        echo ('<h3 style="color:#ff0000; text-align:center"></br>' .$message) . '</br></br>=>Contact the administrator if you are  the system user for help.</br>=>If you are the administrator, this message may come due to misconfiguration in the host machine that authenticate this system.</br>OR</br> The connection to the database server may be unavailable!</h3>';
        echo '<h3 style="text-align:center"></br></br><img src="images/back.gif" style="cursor:pointer" alt="Return"/></br>Click <a href="./">here</a> to return</h3>';
        exit();
    }
    public  function connectToMysqlDb()
    {
        //for mysql
        static $mysqlHost = "10.137.18.15"; #mysql host localhost if on the same machine
        static $mysqlPort = "3306"; #default mysql port but use change
        static $mysqlUser = "dmis_mysql";
        static $mysqlPassword = "dmis@mysql";
        static $database = "mlw_data";

        try
        {
            $db_conn = new PDO("mysql:host=$mysqlHost; port=$mysqlPort; dbname=$database", $mysqlUser, $mysqlPassword);
        }
        catch (PDOException $ex)
        {
            $this->showErrorMessage($ex->getMessage());
        }
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db_conn;
    }
    public function connectToSqlDb()
    {
        //For smsql
        static $sqlHost = "10.137.18.82"; #mssql host localhost if on the same machine
        static $sqlPort = "1433"; #default msssql port but use change
        static $sqlUser = "dmis_su";
        static $sqlPassword = "dmis_su";
        static $database = "dmis_core";
        try
        {
            #driver options for mssql for linux dblib best

            #$db_conn= new PDO("odbc:Driver=FreeTDS; Server=$sqlHost; Port=$sqlPort; Database=$database; UID=$sqlUser; PWD=$sqlPassword");
            #$db_conn= new PDO("dblib:host=$sqlHost:$sqlPort; dbname=$database; charset=UTF8", $sqlUser, $sqlPassword);

            #driver options for mssql for windows
            $db_conn = new PDO("sqlsrv:Server=$sqlHost; Database=$database", $sqlUser, $sqlPassword);

        }
        catch (PDOException $ex)
        {
            $this->showErrorMessage($ex->getMessage());
        }
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        #$db_conn->setAttribute(constant('PDO::SQLSRV_ATTR_DIRECT_QUERY'), true);
        #$db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);production

        /*
        *For linked server some driver properties have to be turned on MSSQL
        */
        $db_conn->exec('SET QUOTED_IDENTIFIER ON');
        $db_conn->exec('SET ANSI_WARNINGS ON');
        $db_conn->exec('SET ANSI_PADDING ON');
        $db_conn->exec('SET ANSI_NULLS ON');
        $db_conn->exec('SET ANSI_NULL_DFLT_ON ON');
        $db_conn->exec('SET CONCAT_NULL_YIELDS_NULL ON');
        $db_conn->exec('SET NOCOUNT ON');
        return $db_conn;
    }

    #DYNAMIC DATABASE CONNECTION
    public function getSoapConnection($soap_array)
    {
        $db_conn = NULL;
        $host = $soap_array['server_ip'];
        $port = $soap_array['server_port'];
        $user = $soap_array["app_uname"];
        $password = $soap_array["app_password"];
        $database = isset($soap_array['db'])?$soap_array['db']:NULL;
        if(!isset($database))
        $database = isset($soap_array['proj_db'])?$soap_array['proj_db']:NULL;
        if ($soap_array['rdbms'] == "SQL Server")
        {
            #mssql
            try
            {
                if(isset($database)) {
                    #linux connection
                    #$db_conn= new PDO("dblib:host=$host:$port; dbname=$database; charset=UTF8", $user, $password);
                    #windows
                    $db_conn = new PDO("sqlsrv:Server=$host; Database=$database", $user, $password);
                }
                else
                {
                    $db_conn= new PDO("dblib:host=$host:$port;charset=UTF8", $user, $password);
                }

            }
            catch (PDOException $ex)
            {
                $this->showErrorMessage($ex->getMessage());
            }
            $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db_conn->exec('SET QUOTED_IDENTIFIER ON');
            $db_conn->exec('SET ANSI_WARNINGS ON');
            $db_conn->exec('SET ANSI_PADDING ON');
            $db_conn->exec('SET ANSI_NULLS ON');
            $db_conn->exec('SET CONCAT_NULL_YIELDS_NULL ON');
            $db_conn->exec('SET NOCOUNT ON');

        }
        else if ($soap_array['rdbms'] == "MySQL")
        {
            //mysql server
            try
            {
                if(isset($database))
                $db_conn = new PDO("mysql:host=$host; port=$port; dbname=$database", $user, $password);
                else
                $db_conn = new PDO("mysql:host=$host; port=$port", $user, $password);
            }
            catch (PDOException $ex)
            {
                $this->showErrorMessage($ex->getMessage());
            }
            $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
		else if ($soap_array['rdbms'] == "PostgreSQL")
        {
            //pgsql server
            try
            {
                if(isset($database))
                $db_conn = new PDO("pgsql:host=$host;port=$port;dbname=$database;user=$user;password=$password");
                else
                $db_conn = new PDO("pgsql:host=$host;port=$port;user=$user;password=$password");
            }
            catch (PDOException $ex)
            {
                $this->showErrorMessage($ex->getMessage());
            }
            $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        return $db_conn;
    }

    public function getDbError($error_code)
    {
        $db_conn=$this->connectToSqlDb();
        try
        {
            $sql="EXEC uspDatabaseErrorMessage_Get @error_code=?";
            $results=$db_conn->prepare($sql);
            $results->bindParam(1, $error_code);
            $results->execute();
            if($results)
            {
                $count=0;
                $error_msg="";
                while($row=$results->fetch(PDO::FETCH_ASSOC))
                {
                    $error_msg.=$row['error_msg'];
                    $count++;
                }
                if($count>0)
                {
                    return $error_msg;
                }
                else
                {
                    return $this->getGeneralError($error_code);
                }

            }
            else
            {
                return $this->getGeneralError($error_code);
            }
        }
        catch(Exception $ex)
        {
            return $this->getGeneralError($error_code);
        }

    }
    public  static  function getGeneralError($error_code)
    {
        return "General Error (".$error_code.")";
    }
    public static function getMailInit()
    {
        $my_array=array();
        $pass="k10089sselb";
        $my_array['name']="blesswellkapalamula@gmail.com";
        $my_array['pass']=$pass;
        $my_array['host']="smtp.gmail.com";
        return $my_array;
    }
}
?>
