<?php
/**
 * Created by PhpStorm.
 * User: BlessK
 * Date: 1/21/2018
 * Time: 12:12 AM
 */
$sys_auth_code="mlw_data";
$project_code=isset($_POST["project_code"])? $_POST["project_code"]:NULL;
$auth_code=isset($_POST["auth_code"])? $_POST["auth_code"]:NULL;
$request_type=isset($_POST["request_type"])? $_POST["request_type"]:NULL;
#request type=update, validate, log
if(isset($project_code) && (isset($auth_code) && $auth_code==$sys_auth_code) && (isset($request_type) && ($request_type=="update" || $request_type=="validate")))
{
    require_once ("classes/FileManager.php");
    $dir="..";
    $doc_root=$dir."/project_files/".$project_code."/".$project_code."_odk_media";
    $file_obj=new FileManager($doc_root);
    $form_folders=$file_obj->getMediaFolder("-media");
    if($form_folders)
    {
        $xml = "<?xml version='1.0' ?>";
        $xml.="<root>";

        foreach ($form_folders as $folder)
        {
            $files=$file_obj->getMediaFile($folder);
            if(count($files)>0)
            {
                foreach($files as $file)
                {
                    //$xml .= "<file>";
                    $xml .= "<path>" . substr($file,2,strlen($file)) . "</path>";
                    //$xml .= "</file>";
                }
            }
        }
        $xml.="</root>";
        if($request_type=="update")
        {
            #log activity
            try
            {
                $device_id=isset($_POST["device_id"])? $_POST["device_id"]:NULL;
                $android_id=isset($_POST["android_id"])? $_POST["android_id"]:NULL;
                $imei=isset($_POST["imei"])? $_POST["imei"]:NULL;
                $serial=isset($_POST["serial"])? $_POST["serial"]:NULL;
                $android_version=isset($_POST["android_version"])? $_POST["android_version"]:NULL;
                $status=1;
                require_once ("config/pdo_connect_class.php");
                $connection=new DatabaseConnection();
                $db_conn=$connection->connectToMysqlDb();
                $sql="CALL lu_uspDeviceLog_Add(:device_id,:android_id,:imei,:serial,:proj_code,:android_version,:status)";
                $results_log=$db_conn->prepare($sql);
                if(isset($device_id))
                    $results_log->bindParam(":device_id",$device_id);
                else
                    $results_log->bindValue(":device_id",$device_id);
                if(isset($android_id))
                    $results_log->bindParam(":android_id",$android_id);
                else
                    $results_log->bindValue(":android_id",$android_id);
                if(isset($imei))
                    $results_log->bindParam(":imei",$imei);
                else
                    $results_log->bindValue(":imei",$imei);
                if(isset($serial))
                    $results_log->bindParam(":serial",$serial);
                else
                    $results_log->bindValue(":serial",$serial);
                $results_log->bindParam(":proj_code",$project_code);
                if(isset($android_version))
                    $results_log->bindParam(":android_version",$android_version);
                else
                    $results_log->bindValue(":android_version",$android_version);
                $results_log->bindParam(":status",$status);
                $results_log->execute();
                if($results_log)
                {
                    echo $xml;
                    exit();
                }
                else
                {
                    echo "Error : Could not log the activity for :".$project_code ." level 1.";
                    exit();
                }

            }
            catch (Exeption $e)
            {
                echo "Error : Could not log the activity for :".$project_code ." level 2.";
                exit();

            }
        }
        else
        {
            echo $xml;
            exit();

        }
    }
    echo "Error : No media file found for project :".$project_code;
}
else if(isset($auth_code) && ($auth_code!=$sys_auth_code)  && (isset($request_type) && $request_type=="validate"))
{
    echo "Error : Invalid Authentication code!";
}
else if(isset($auth_code) && ($auth_code!=$sys_auth_code)  && (isset($request_type) && $request_type=="log"))
{
    #log activity
    $device_id=isset($_POST["device_id"])? $_POST["device_id"]:NULL;
    $android_id=isset($_POST["android_id"])? $_POST["android_id"]:NULL;
    $imei=isset($_POST["imei"])? $_POST["imei"]:NULL;
    $serial=isset($_POST["serial"])? $_POST["serial"]:NULL;
    $status=0;
    require_once ("config/pdo_connect_class.php");
    $connection=new DatabaseConnection();
    $db_conn=$connection->connectToMysqlDb();
    $sql="CALL lu_uspDeviceLog_Add(:device_id,:android_id,:imei,:serial,:proj_code,:android_version,:status)";
    $results_log=$db_conn->prepare($sql);
    if(isset($device_id))
        $results_log->bindParam(":device_id",$device_id);
    else
        $results_log->bindValue(":device_id",$device_id);
    if(isset($android_id))
        $results_log->bindParam(":android_id",$android_id);
    else
        $results_log->bindValue(":android_id",$android_id);
    if(isset($imei))
        $results_log->bindParam(":imei",$imei);
    else
        $results_log->bindValue(":imei",$imei);
    if(isset($serial))
        $results_log->bindParam(":serial",$serial);
    else
        $results_log->bindValue(":serial",$serial);
    $results_log->bindParam(":proj_code",$project_code);
    if(isset($android_version))
        $results_log->bindParam(":android_version",$android_version);
    else
        $results_log->bindValue(":android_version",$android_version);
    $results_log->bindParam(":status",$status);
    $results_log->execute();
    if($results_log)
    {
        $msg="Lookup updater log successfully";
        echo $msg;
    }
    else
    {
        $msg="Lookup updater failed to log the action";
        echo $msg;
    }
    exit();
}
else
{
    echo "Error : General error. Invalid parameters ";
}
?>